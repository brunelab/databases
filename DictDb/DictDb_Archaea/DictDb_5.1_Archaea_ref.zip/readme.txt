DictDb_5.1_Archaea reference alignment and taxonomy files for automated classification software 

Please cite:

Protasov E, Nonoh JO, Kästle Silva JM, Mies US, Hervé V, Dietrich C, Lang K, Mikulski L,
Platt K, Poehlein A, Köhler-Ramm T, Miambi E, Boga HI, Feldewert C, Ngugi DK,
Plarre R, Sillam-Dussés D, Sobotnik J, Daniel R, and Brune A (2023)
Diversity and taxonomic revision of methanogens and other archaea in the intestinal tract
of terrestrial arthropods. Front. Microbiol. 14 - 2023.
doi: 10.3389/fmicb.2023.1281628

These reference files are compatible with the mothur software and can be used with the classify.seqs command.

DictDb_5.1_Archaea is based on a dereplicated version of SILVA SSU 138.1 
(https://www.arb-silva.de/projects/ssu-ref-nr/)
The alignment was manually curated and improved for Methanobacteriales, Methanomicrobiales, 
Methanosarcinales, Methanomassiliicoccales, Nitrososphaerales and Bathyarcheia.
Archaeal SSU gene sequences from clone libraries, next generation amplicon libraries, and 
metagenome-assembled genomes (MAGs) from arthropod guts were added.

The taxonomy strings were updated and harmonized with the GTDB release 207 and include the new taxa 
described in Protasov et al. (2023). 

Archaeal lineages not found in arthropod guts are represented by sequences from the SBDI Sativa curated 
GTDB database (doi: 10.17044/scilifelab.14869077.v5).

Sequences of E. coli and B. subtilis were included in the ref files to filter out bacterial reads from datasets.

Contact email: joana.kaestle@mpi-marburg.mpg.de