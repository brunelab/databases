DictDb_5.1_Archaea_readme.txt

This SSU database was curated by Joana M. Kästle Silva and Andreas Brune.
It is based on the reference database SSURef release 138.1, 27.08.2020 by the 
SILVA project (https://www.arb-silva.de/projects/ssu-ref-nr/).

Please cite:
Quast C, Pruesse E, Yilmaz P, Gerken J, Schweer T, Yarza P, Peplies J, Glockner FO (2013)
The SILVA ribosomal RNA gene database project: improved data processing and web-based tools.
Nucleic Acid Res. 41:D590-D596

Protasov E, Nonoh JO, Kästle Silva JM, Mies US, Hervé V, Dietrich C, Lang K, Mikulski L,
Platt K, Poehlein A, Köhler-Ramm T, Miambi E, Boga HI, Feldewert C, Ngugi DK,
Plarre R, Sillam-Dussés D, Sobotnik J, Daniel R, and Brune A (2023)
Diversity and taxonomic revision of methanogens and other archaea in the intestinal tract
of terrestrial arthropods. Front. Microbiol. 14 - 2023.
doi: 10.3389/fmicb.2023.1281628
 
The SILVA reference database was dereplicated keeping only one representative each 
from 99%-identity clusters.

Archaeal SSU gene sequences from clone libraries, next generation amplicon libraries, and 
metagenome-assembled genomes (MAGs) from arthropod guts were added.

Metadata of clone libraries, metagenomic bins, next generation sequencing projects and 
isolates can be found under designated species fields. 

Host groups are colored for easier visualization and saved under species selections:
(Arb color - sample source)

0 - environmental/others
1 - SSUs from MAGs
2 - lower termites
3 - higher termites 
4 - beetles 
6 - millipedes 
8 - ruminants/mammals/feces
9 - food soil 
12 - cockroaches
 
The database contains a tree_all scaffold of the Silva (release 138.1) SSU reference database, 
as well as taxa-specific subtrees containing long reference sequences (_iqtree_ref) or, additionally, 
short sequences (_add) from clone libraries. To ease the link to phylogenomic classification, 
16S sequences from the SBDI Sativa curated GTDB database (https://doi.org/10.17044/scilifelab.14869077.v5)
have been imported to the database.

New maximum-likelihood trees for Methanobacteriales, Methanomicrobiales, Methanosarcinales, 
Methanomassiliicoccales, Nitrososphaerales and Bathyarcheia were inferred using IQ-TREE 2 and 
imported to the database. The taxonomy strings were updated and harmonized with the GTDB release 207. 

New improved alignment filters calculated using maximum frequency: Methanobacteria, Methanomicrobia, 
Thermoplasmatota, Thermoproteota. 

Taxonomy and alignment files for classification software are available at 
https://github.com/brunelab/databases.

Contact email: brune@mpi-marburg.mpg.de, joana.kaestle@mpi-marburg.mpg.de